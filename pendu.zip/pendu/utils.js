// function getRandomInteger(min, max){
//     return .floo(math.random() * (max - min) + min);
// }

// function slugify(word){


// }





